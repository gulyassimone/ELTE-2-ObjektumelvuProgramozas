#ifndef DESK_H
#define DESK_H


class Desk
{
    public:
        Desk();
    private:
};

#endif // DESK_H
