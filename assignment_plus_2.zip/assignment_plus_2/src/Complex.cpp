#include "Complex.h"

Complex::Complex()
{
    //ctor
}

Complex::~Complex()
{
    //dtor
}
