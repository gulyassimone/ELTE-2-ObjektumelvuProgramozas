#ifndef COMPLEX_H
#define COMPLEX_H


class Complex
{
    public:
        Complex();
        virtual ~Complex();

    protected:

    private:
};

#endif // COMPLEX_H
