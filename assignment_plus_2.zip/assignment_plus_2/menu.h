#pragma once
#include "complex.h"
#include <fstream>

class Menu
{
public:
    void run();
private:
    void menuWrite();
    void case1();
    void case2();
    void case3();
    void case4();
    void case5();
};
