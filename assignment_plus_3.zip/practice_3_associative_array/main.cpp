#include <iostream>
#include "menu.h"


using namespace std;

int main()
{
    Menu menu;
    menu.run();

    return 0;
}
